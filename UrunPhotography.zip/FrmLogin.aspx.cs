﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Urunfotografim.RoleManagement;

namespace UrunPhotography
{
    public partial class FrmLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;
        }
        DBUrnPhotographyEntities db = new DBUrnPhotographyEntities();
        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                var rec = db.tbllogins.Where(b => b.Email == TxtUserName.Text && b.PWD.Equals(TxtPassword.Text)).FirstOrDefault();


                if (rec != null)
                {
                    Session["Email"] = TxtUserName.Text;
                    Session["RoleID"] = rec.RoleID;

                    if (WebsiteRoles.IsAdministrater())
                    {
                        Response.Redirect("FrmAddProduct.aspx");
                    }
                    else if (WebsiteRoles.IsCustomer())
                    {
                        Session["CustomerID"] = rec.CustomerID;
                        Response.Redirect("FrmCustomerOrder.aspx");
                       
                    }

                }
                else
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "Incorrect Password";
                    lblmsg.ForeColor = System.Drawing.Color.Red;
                }
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }
    }
}