﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UrunPhotography
{
    public partial class ProductsAndAddsOn : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                MthdFillDrpProduct();
                MthdFillDrpCategory();
                MthdFillDrpAddsOn();
                MthdFillDrpCat();

            }
            MthdFillRepeaterAddsOn();
            btnUpdate.Visible = false;
            lblmsg.Visible = false;
        }
        DBUrnPhotographyEntities db = new DBUrnPhotographyEntities();
        public void MthdFillDrpProduct()
        {
            DrpProduct.DataSource = (from a in db.tblProducts
                                     select new { a.ProductID, a.ProductName }).ToList();
            DrpProduct.DataValueField = "ProductID";
            DrpProduct.DataTextField = "ProductName";
            DrpProduct.DataBind();
        }
        public void MthdFillDrpCategory()
        {
            DrpCategory.DataSource = (from a in db.tblAddOnCategories
                                      select new { a.AddOnCategoryID, a.CategoryDesc }).ToList();
            DrpCategory.DataValueField = "AddOnCategoryID";
            DrpCategory.DataTextField = "CategoryDesc";
            DrpCategory.DataBind();
        }
        public void MthdFillDrpCat()
        {
            DrpCat.DataSource = (from a in db.tblAddOnCategories
                                 select new { a.AddOnCategoryID, a.CategoryDesc }).ToList();
            DrpCat.DataValueField = "AddOnCategoryID";
            DrpCat.DataTextField = "CategoryDesc";
            DrpCat.DataBind();
        }
        public void MthdFillDrpAddsOn()
        {
            int ID = int.Parse(DrpCategory.SelectedValue.ToString());
            ChkAddsOnName.DataSource = (from a in db.tblAddOns
                                        select new { a.AddOnID, a.AddOn, a.AddOnCategoryID }).ToList().Where(p => p.AddOnCategoryID == ID);
            ChkAddsOnName.DataValueField = "AddOnID";
            ChkAddsOnName.DataTextField = "AddOn";
            ChkAddsOnName.DataBind();
        }
        public void MthdFillRepeaterAddsOn()
        {
            string Category = DrpCat.SelectedItem.Text;
            Repeater1.DataSource = db.SpFillRepProductAddOnUpdated().Where(p => p.CategoryDesc == Category).ToList();
            Repeater1.DataBind();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            tblProductAddOn obj = new tblProductAddOn();

            foreach (ListItem item in ChkAddsOnName.Items)
            {
                if (item.Selected)
                {
                    obj.AddOnID = int.Parse(item.Value);
                    obj.ProductID = int.Parse(DrpProduct.SelectedValue.ToString());
                    db.tblProductAddOns.Add(obj);
                    db.SaveChanges();
                }

            }
            ChkAddsOnName.ClearSelection();

            lblmsg.Visible = true;
            lblmsg.Text = "Product Mapped Success";
            lblmsg.ForeColor = System.Drawing.Color.Green;
            MthdFillRepeaterAddsOn();
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblProductAddOn obj1 = db.tblProductAddOns.FirstOrDefault(r => r.ProductAddOnID == id);


                    DrpProduct.SelectedValue = obj1.ProductID.ToString();
                    ChkAddsOnName.SelectedValue = obj1.AddOnID.ToString();

                    btnAdd.Visible = false;
                    btnUpdate.Visible = true;

                    break;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                int id = int.Parse(HiddenField1.Value);
                var row = db.tblProductAddOns.Where(a => a.ProductAddOnID == id).FirstOrDefault();
                if (row != null)
                {


                    row.AddOnID = int.Parse(ChkAddsOnName.SelectedValue.ToString());
                    row.ProductID = int.Parse(DrpProduct.SelectedValue.ToString());

                    db.SaveChanges();
                    MthdFillRepeaterAddsOn();


                    lblmsg.Visible = true;
                    lblmsg.Text = "Map Updated Successfully";
                    lblmsg.ForeColor = System.Drawing.Color.Green;

                    btnAdd.Visible = true;
                    btnUpdate.Visible = false;






                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        protected void DrpCat_SelectedIndexChanged(object sender, EventArgs e)
        {
            MthdFillRepeaterAddsOn();
        }

        protected void DrpCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            MthdFillDrpAddsOn();
        }
    }
}