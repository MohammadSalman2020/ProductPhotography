﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UrunPhotography
{
    public partial class FrmAddProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;

            MthdFillRepeater();
        }
        public bool Empty()
        {
            if (txtProductName.Text.Trim() == string.Empty)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void Clear()
        {
            txtProductName.Text = "";
            txtTypePrice.Text = "";
            txtExtraPrice.Text = "";
        }
        DBUrnPhotographyEntities db = new DBUrnPhotographyEntities();
        public void MthdFillRepeater()
        {
            Repeater1.DataSource = db.tblProducts.ToList().OrderByDescending(p => p.ProductID);
            Repeater1.DataBind();
        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (!Empty())
            {
                tblProduct obj = new tblProduct();

                obj.ProductName = txtProductName.Text;
                obj.ProductType = DrpProduct.SelectedItem.Text;

                if (txtExtraPrice.Text == "")
                {
                    obj.ProductExtra = 0.ToString();
                }
                else
                {
                    obj.ProductExtra = txtExtraPrice.Text;
                }

                if (txtTypePrice.Text == "")
                {
                    obj.ProductTypePrice = 0;
                }
                else
                {
                    obj.ProductTypePrice = float.Parse(txtTypePrice.Text);
                }


                db.tblProducts.Add(obj);
                db.SaveChanges();

                lblmsg.Visible = true;
                lblmsg.Text = "Product Added Succesfully";
                lblmsg.ForeColor = System.Drawing.Color.Green;

                Clear();
                MthdFillRepeater();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;

            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblProduct obj1 = db.tblProducts.FirstOrDefault(r => r.ProductID == id);


                    txtExtraPrice.Text = obj1.ProductExtra.ToString();
                    txtProductName.Text = obj1.ProductName.ToString();
                    txtTypePrice.Text = obj1.ProductTypePrice.ToString();
                    DrpProduct.SelectedItem.Text = obj1.ProductType;
                    DrpProduct2.SelectedItem.Text = obj1.ProductType;



                    btnAdd.Visible = false;
                    btnUpdate.Visible = true;





                    break;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                int id = int.Parse(HiddenField1.Value);
                var row = db.tblProducts.Where(a => a.ProductID == id).FirstOrDefault();
                if (row != null)
                {


                    if (!Empty())
                    {
                        row.ProductType = DrpProduct.SelectedItem.Text;


                        row.ProductName = txtProductName.Text;

                        row.ProductExtra = txtExtraPrice.Text;
                        row.ProductTypePrice = float.Parse(txtTypePrice.Text);

                        db.SaveChanges();
                        MthdFillRepeater();

                        Clear();
                        lblmsg.Visible = true;
                        lblmsg.Text = "Record Updated Successfully";
                        lblmsg.ForeColor = System.Drawing.Color.Green;

                        btnAdd.Visible = true;
                        btnUpdate.Visible = false;
                    }
                    else
                    {
                        lblmsg.Visible = true;
                        lblmsg.Text = "Fill All Fields";
                        lblmsg.ForeColor = System.Drawing.Color.Green;
                        btnAdd.Visible = true;
                        btnUpdate.Visible = false;
                    }









                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
    }
}