﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UrunPhotography
{
    public partial class FrmPunchOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                ShowHide();
                MthdFillDrpProduct();
                MthdFillAddOns();
                MthdFillDrpscloths();
                Session["InitialTotal"] = LblTotal.Text;
            }

        

        }
        public void ShowHide()
        {
            int x = DrpSelect.SelectedIndex;

            if (x == 0)
            {
                divProduct.Visible = true;
                DivCloths.Visible = false;
                DivImgProduct.Visible = true;
                DivTextCloths.Visible = false;
                DivImgColths.Visible = false;
                LblTotal.Text = "100.00";


            }
            else if (x == 1)
            {
                DivCloths.Visible = true;
                divProduct.Visible = false;
                DivImgColths.Visible = true;
                DivTextCloths.Visible = true;
                DivImgProduct.Visible = false;
                LblTotal.Text = "100.00";

            }
        }

        protected void DrpSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowHide();

        }

        protected void btnPlus_Click(object sender, EventArgs e)
        {


            btnMinus.Visible = true;

            int Number = int.Parse(lblQuantity.Text);
            int Total = Number + 1;




            lblQuantity.Text = Total.ToString();

            float TotalAmount = float.Parse(LblTotal.Text);

            float InitialTotal = float.Parse(Session["InitialTotal"].ToString());

            float FinalTotal = TotalAmount + InitialTotal;

            LblTotal.Text = FinalTotal.ToString();







        }

        protected void btnMinus_Click(object sender, EventArgs e)
        {
            

            int Number = int.Parse(lblQuantity.Text);

            int Total = Number - 1;

            if(Total==1)
            {
                btnMinus.Visible = false;
                lblQuantity.Text = Total.ToString();

                float InitialTotal = float.Parse(Session["InitialTotal"].ToString());

                float TotalAmount = float.Parse(LblTotal.Text) - InitialTotal;

                //  float FinalTotal = TotalAmount * Total;

                LblTotal.Text = TotalAmount.ToString();
            }
            else
            {
                btnMinus.Visible = true;
                lblQuantity.Text = Total.ToString();

                float InitialTotal = float.Parse(Session["InitialTotal"].ToString());

                float TotalAmount = float.Parse(LblTotal.Text) - InitialTotal;

                //  float FinalTotal = TotalAmount * Total;

                LblTotal.Text = TotalAmount.ToString();
            }

          



        }


        DBUrnPhotographyEntities db = new DBUrnPhotographyEntities();
        public void MthdFillDrpProduct()
        {



            DrpProduct.DataSource = (from a in db.tblProducts
                                     let x = a.ProductName

                                     select new { a.ProductID, x, a.ProductType }).Where(p => p.ProductType == "Standard Product").ToList();
            DrpProduct.DataValueField = "ProductID";
            DrpProduct.DataTextField = "x";
            DrpProduct.DataBind();

        }

        public void MthdFillAddOns()
        {

            //var rec= (from a in db.tblAddOnCategories
            //                                   select new { a.CategoryDesc, a.AddOnCategoryID }).Where(p => p.AddOnCategoryID == 1).ToList();



            // var id = db.tblAddOnCategories.Where(p=>p.CategoryDesc=="Group Photos: # Of Items In The Photo").FirstOrDefault();
            chkCekim.DataSource = db.SpFillChecksForCekim().ToList();


            chkCekim.DataValueField = "AddOnID";
            chkCekim.DataTextField = "Price";
            chkCekim.DataBind();
            chkCekim.SelectedIndex = 0;




            ChkGroup.DataSource = db.SpFillChecksForGroupUpdated1().ToList();
            ChkGroup.DataValueField = "AddOnID";
            ChkGroup.DataTextField = "Price";
            ChkGroup.DataBind();
            ChkGroup.SelectedIndex = 0;






            ChkBackground.DataSource = db.SpFillChkBackground().ToList();


            ChkBackground.DataValueField = "AddOnID";
            ChkBackground.DataTextField = "Price";
            ChkBackground.DataBind();
            ChkBackground.SelectedIndex = 0;

            ChkHandPhotos.DataSource = db.SpFillChkHandPhotos().ToList();


            ChkHandPhotos.DataValueField = "AddOnID";
            ChkHandPhotos.DataTextField = "Price";
            ChkHandPhotos.DataBind();
            ChkHandPhotos.SelectedIndex = 0;

            //from here change price as well

            ChkTurnAround.DataSource = db.SpFillChkTurnAround().ToList();


            ChkTurnAround.DataValueField = "AddOnID";
            ChkTurnAround.DataTextField = "Price";
            ChkTurnAround.DataBind();
            ChkTurnAround.SelectedIndex = 0;

            ChkProduct.DataSource = db.SpFillChkProduct().ToList();


            ChkProduct.DataValueField = "AddOnID";
            ChkProduct.DataTextField = "Price";
            ChkProduct.DataBind();
            ChkProduct.SelectedIndex = 0;



            ChkStandard.DataSource = db.SpFillChkStandard().ToList();


            ChkStandard.DataValueField = "AddOnID";
            ChkStandard.DataTextField = "Price";
            ChkStandard.DataBind();
            ChkStandard.SelectedIndex = 0;



            //checkAdvanced.DataSource = db.SpFillchkAdvanced().ToList();


            //checkAdvanced.DataValueField = "AddOnID";
            //checkAdvanced.DataTextField = "Price";
            //checkAdvanced.DataBind();
            //checkAdvanced.SelectedIndex = 0;
        }


        //from here
        public void MthdFillDrpscloths()
        {
            ChkPicAngle.DataSource = db.SpFillDrpscloths().ToList();


            ChkPicAngle.DataValueField = "AddOnID";
            ChkPicAngle.DataTextField = "Price";
            ChkPicAngle.DataBind();
            ChkPicAngle.SelectedIndex = 0;


            ChkClothTurnAround.DataSource = db.SpFillClothTurnAround().ToList();


            ChkClothTurnAround.DataValueField = "AddOnID";
            ChkClothTurnAround.DataTextField = "Price";
            ChkClothTurnAround.DataBind();
            ChkClothTurnAround.SelectedIndex = 0;

            ChkClothStandard.DataSource = db.SpFillChkClothStandard().ToList();


            ChkClothStandard.DataValueField = "AddOnID";
            ChkClothStandard.DataTextField = "Price";
            ChkClothStandard.DataBind();
            ChkClothStandard.SelectedIndex = 0;

            //ChkClothAdnvanced.DataSource = db.SpFillChkClothAdnvanced().ToList();


            //ChkClothAdnvanced.DataValueField = "AddOnID";
            //ChkClothAdnvanced.DataTextField = "Price";
            //ChkClothAdnvanced.DataBind();
            //ChkClothAdnvanced.SelectedIndex = 0;

            ChkCekimCloth.DataSource = db.SpFillChecksForCekim().ToList();


            ChkCekimCloth.DataValueField = "AddOnID";
            ChkCekimCloth.DataTextField = "Price";
            ChkCekimCloth.DataBind();
            ChkCekimCloth.SelectedIndex = 0;


            ChkGroupCloth.DataSource = db.SpFillChecksForGroupUpdated1().ToList();
            ChkGroupCloth.DataValueField = "AddOnID";
            ChkGroupCloth.DataTextField = "Price";
            ChkGroupCloth.DataBind();
            ChkGroupCloth.SelectedIndex = 0;

            ChkProductCloth.DataSource = db.SpFillChkProduct().ToList();


            ChkProductCloth.DataValueField = "AddOnID";
            ChkProductCloth.DataTextField = "Price";
            ChkProductCloth.DataBind();
            ChkProductCloth.SelectedIndex = 0;




            ChkBackgroundCloth.DataSource = db.SpFillChkBackground().ToList();


            ChkBackgroundCloth.DataValueField = "AddOnID";
            ChkBackgroundCloth.DataTextField = "Price";
            ChkBackgroundCloth.DataBind();
            ChkBackgroundCloth.SelectedIndex = 0;

            ChkHandPhotosCloth.DataSource = db.SpFillChkHandPhotos().ToList();


            ChkHandPhotosCloth.DataValueField = "AddOnID";
            ChkHandPhotosCloth.DataTextField = "Price";
            ChkHandPhotosCloth.DataBind();
            ChkHandPhotosCloth.SelectedIndex = 0;
        }


        protected void DrpProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            MthdFillAddOns();
            //if (DrpProduct.SelectedIndex == 1 || DrpProduct.SelectedIndex == 2)
            //{
            //    DivPro.Visible = false;
            //}
            //else
            //{
            //    DivPro.Visible = true;
            //}
        }


        protected void ChkGroup_SelectedIndexChanged(object sender, EventArgs e)
        {



            int AddOnID = int.Parse(ChkGroup.SelectedValue.ToString());


            if (ViewState["ChkGroup"] == null)
            {
                ViewState["ChkGroup"] = ChkGroup.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["ChkGroup"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["ChkGroup"] = ChkGroup.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();




            Session["InitialTotal"] = LblTotal.Text;


        }




        protected void ChkBackground_SelectedIndexChanged(object sender, EventArgs e)
        {



            int AddOnID = int.Parse(ChkBackground.SelectedValue.ToString());


            if (ViewState["ChkBackground"] == null)
            {
                ViewState["ChkBackground"] = ChkBackground.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["ChkBackground"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["ChkBackground"] = ChkBackground.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();

            Session["InitialTotal"] = LblTotal.Text;


        }

        protected void ChkHandPhotos_SelectedIndexChanged(object sender, EventArgs e)
        {





            int AddOnID = int.Parse(ChkHandPhotos.SelectedValue.ToString());


            if (ViewState["ChkHandPhotos"] == null)
            {
                ViewState["ChkHandPhotos"] = ChkHandPhotos.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["ChkHandPhotos"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["ChkHandPhotos"] = ChkHandPhotos.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();

            Session["InitialTotal"] = LblTotal.Text;
        }

        protected void ChkTurnAround_SelectedIndexChanged(object sender, EventArgs e)
        {


            int AddOnID = int.Parse(ChkTurnAround.SelectedValue.ToString());


            if (ViewState["ChkTurnAround"] == null)
            {
                ViewState["ChkTurnAround"] = ChkTurnAround.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["ChkTurnAround"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["ChkTurnAround"] = ChkTurnAround.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();

            Session["InitialTotal"] = LblTotal.Text;
        }

        protected void ChkProduct_SelectedIndexChanged(object sender, EventArgs e)
        {


            int AddOnID = int.Parse(ChkProduct.SelectedValue.ToString());


            if (ViewState["ChkProduct"] == null)
            {
                ViewState["ChkProduct"] = ChkProduct.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["ChkProduct"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["ChkProduct"] = ChkProduct.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();

            Session["InitialTotal"] = LblTotal.Text;
        }

        protected void ChkStandard_SelectedIndexChanged(object sender, EventArgs e)
        {


            int AddOnID = int.Parse(ChkStandard.SelectedValue.ToString());


            if (ViewState["ChkStandard"] == null)
            {
                ViewState["ChkStandard"] = ChkStandard.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["ChkStandard"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["ChkStandard"] = ChkStandard.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();

            Session["InitialTotal"] = LblTotal.Text;
        }

        protected void checkAdvanced_SelectedIndexChanged(object sender, EventArgs e)
        {
            //int AddOnID = int.Parse(checkAdvanced.SelectedValue.ToString());

            //tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            //float AddOnPrice = float.Parse(obj1.AddOnPrice);

            //float TotalTextBox = float.Parse(LblTotal.Text);

            //float Total = Total = AddOnPrice + TotalTextBox;

            //LblTotal.Text = Total.ToString();
        }

        protected void ChkPicAngle_SelectedIndexChanged(object sender, EventArgs e)
        {


            int AddOnID = int.Parse(ChkPicAngle.SelectedValue.ToString());


            if (ViewState["ChkPicAngle"] == null)
            {
                ViewState["ChkPicAngle"] = ChkPicAngle.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["ChkPicAngle"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["ChkPicAngle"] = ChkPicAngle.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();
            Session["InitialTotal"] = LblTotal.Text;
        }

        protected void ChkClothTurnAround_SelectedIndexChanged(object sender, EventArgs e)
        {


            int AddOnID = int.Parse(ChkClothTurnAround.SelectedValue.ToString());


            if (ViewState["ChkClothTurnAround"] == null)
            {
                ViewState["ChkClothTurnAround"] = ChkClothTurnAround.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["ChkClothTurnAround"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["ChkClothTurnAround"] = ChkClothTurnAround.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();

            Session["InitialTotal"] = LblTotal.Text;
        }

        protected void ChkClothStandard_SelectedIndexChanged(object sender, EventArgs e)
        {


            int AddOnID = int.Parse(ChkClothStandard.SelectedValue.ToString());


            if (ViewState["ChkClothStandard"] == null)
            {
                ViewState["ChkClothStandard"] = ChkClothStandard.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["ChkClothStandard"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["ChkClothStandard"] = ChkClothStandard.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();

            Session["InitialTotal"] = LblTotal.Text;
        }

        protected void ChkClothAdnvanced_SelectedIndexChanged(object sender, EventArgs e)
        {
            //int AddOnID = int.Parse(ChkClothAdnvanced.SelectedValue.ToString());

            //tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            //float AddOnPrice = float.Parse(obj1.AddOnPrice);

            //float TotalTextBox = float.Parse(LblTotal.Text);

            //float Total = Total = AddOnPrice + TotalTextBox;

            //LblTotal.Text = Total.ToString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string hostName = Dns.GetHostName(); // Retrive the Name of HOST  

            string IP = Dns.GetHostByName(hostName).AddressList[0].ToString();
            int x = DrpSelect.SelectedIndex;

            tblAddtoCart obj = new tblAddtoCart();

            if (x == 0)
            {



                obj.ProductType = DrpSelect.SelectedItem.Text;
                obj.IP = IP;
                obj.ProductID = int.Parse(DrpProduct.SelectedValue.ToString());
                obj.GroupPhotosItem = int.Parse(ChkGroup.SelectedValue.ToString());
                obj.BackgroundItem = int.Parse(ChkBackground.SelectedValue.ToString());
                obj.HandPhotosItem = int.Parse(ChkHandPhotos.SelectedValue.ToString());
                obj.TurnAroundTimeItem = int.Parse(ChkTurnAround.SelectedValue.ToString());
                obj.CekimTuru = int.Parse(chkCekim.SelectedValue.ToString());
                if (DrpProduct.SelectedIndex == 1 || DrpProduct.SelectedIndex == 2)
                {
                    obj.ProductSizeItem = null;
                }
                else
                {

                    obj.ProductSizeItem = int.Parse(ChkProduct.SelectedValue.ToString());
                }
                obj.StandardTypeItem = int.Parse(ChkStandard.SelectedValue.ToString());
                //obj.AdvancedType = int.Parse(checkAdvanced.SelectedValue.ToString());

                obj.Qty = int.Parse(lblQuantity.Text);
                obj.TotalAmount = float.Parse(LblTotal.Text);
                obj.Order_Date = DateTime.Now;


                db.tblAddtoCarts.Add(obj);
                db.SaveChanges();

                Session["Type"] = "Product";
            }
            else if (x == 1)
            {
                obj.ProductType = DrpSelect.SelectedItem.Text;
                obj.IP = IP;

                if (ChkPic1.Checked == true)
                {
                    obj.ProductID = 32;
                }
                else if (ChkPic2.Checked == true)
                {
                    obj.ProductID = 33;
                }


                obj.PickYourClothingAngle = int.Parse(ChkPicAngle.SelectedValue.ToString());
                obj.TurnAroundTimeItem = int.Parse(ChkClothTurnAround.SelectedValue.ToString());
                obj.GroupPhotosItem = int.Parse(ChkGroupCloth.SelectedValue.ToString());
                obj.StandardTypeItem = int.Parse(ChkStandard.SelectedValue.ToString());
                //obj.AdvancedType = int.Parse(checkAdvanced.SelectedValue.ToString());

                obj.ProductSizeItem = int.Parse(ChkProductCloth.SelectedValue.ToString());

                obj.BackgroundItem = int.Parse(ChkBackgroundCloth.SelectedValue.ToString());
                obj.HandPhotosItem = int.Parse(ChkHandPhotosCloth.SelectedValue.ToString());
                obj.CekimTuru = int.Parse(ChkCekimCloth.SelectedValue.ToString());

                obj.Qty = int.Parse(lblQuantity.Text);
                obj.TotalAmount = float.Parse(LblTotal.Text);
                obj.Order_Date = DateTime.Now;

                db.tblAddtoCarts.Add(obj);
                db.SaveChanges();
                Session["Type"] = "Clothing";
            }


            Session["IP"] = IP.ToString();


            Response.Redirect("frmCart.aspx");





        }

        protected void chkCekim_SelectedIndexChanged(object sender, EventArgs e)
        {


            int AddOnID = int.Parse(chkCekim.SelectedValue.ToString());


            if (ViewState["chkCekim"] == null)
            {
                ViewState["chkCekim"] = chkCekim.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["chkCekim"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["chkCekim"] = chkCekim.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();

            Session["InitialTotal"] = LblTotal.Text;
        }

        protected void ChkCekimCloth_SelectedIndexChanged(object sender, EventArgs e)
        {


            int AddOnID = int.Parse(ChkCekimCloth.SelectedValue.ToString());


            if (ViewState["ChkCekimCloth"] == null)
            {
                ViewState["ChkCekimCloth"] = ChkCekimCloth.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["ChkCekimCloth"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["ChkCekimCloth"] = ChkCekimCloth.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();

            Session["InitialTotal"] = LblTotal.Text;
        }

        protected void ChkGroupCloth_SelectedIndexChanged(object sender, EventArgs e)
        {


            int AddOnID = int.Parse(ChkGroupCloth.SelectedValue.ToString());


            if (ViewState["ChkGroupCloth"] == null)
            {
                ViewState["ChkGroupCloth"] = ChkGroupCloth.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["ChkGroupCloth"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["ChkGroupCloth"] = ChkGroupCloth.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();

            Session["InitialTotal"] = LblTotal.Text;
        }

        protected void ChkBackgroundCloth_SelectedIndexChanged(object sender, EventArgs e)
        {


            int AddOnID = int.Parse(ChkBackgroundCloth.SelectedValue.ToString());


            if (ViewState["ChkBackgroundCloth"] == null)
            {
                ViewState["ChkBackgroundCloth"] = ChkBackgroundCloth.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["ChkBackgroundCloth"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["ChkBackgroundCloth"] = ChkBackgroundCloth.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();

            Session["InitialTotal"] = LblTotal.Text;
        }

        protected void ChkHandPhotosCloth_SelectedIndexChanged(object sender, EventArgs e)
        {


            int AddOnID = int.Parse(ChkHandPhotosCloth.SelectedValue.ToString());


            if (ViewState["ChkHandPhotosCloth"] == null)
            {
                ViewState["ChkHandPhotosCloth"] = ChkHandPhotosCloth.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["ChkHandPhotosCloth"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["ChkHandPhotosCloth"] = ChkHandPhotosCloth.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();

            Session["InitialTotal"] = LblTotal.Text;
        }

        protected void ChkProductCloth_SelectedIndexChanged(object sender, EventArgs e)
        {


            int AddOnID = int.Parse(ChkProductCloth.SelectedValue.ToString());


            if (ViewState["ChkProductCloth"] == null)
            {
                ViewState["ChkProductCloth"] = ChkProductCloth.SelectedValue.ToString();
            }
            else
            {
                int LastAddOnID = int.Parse(ViewState["ChkProductCloth"].ToString());
                tblAddOn obj2 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == LastAddOnID);
                float OldAddOnPrice = 0;

                bool parsing2 = float.TryParse(obj2.AddOnPrice, out OldAddOnPrice);



                float BeforeTotal = float.Parse(LblTotal.Text) - OldAddOnPrice;

                LblTotal.Text = BeforeTotal.ToString();

                ViewState["ChkProductCloth"] = ChkProductCloth.SelectedValue.ToString();

            }


            tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == AddOnID);



            float AddOnPrice = 0;

            bool Parsing = float.TryParse(obj1.AddOnPrice, out AddOnPrice);

            float TotalChkBackgroundTextBox = float.Parse(LblTotal.Text);



            float SubTotal = AddOnPrice + TotalChkBackgroundTextBox;

            LblTotal.Text = SubTotal.ToString();

            Session["InitialTotal"] = LblTotal.Text;
        }

        protected void ChkPic1_CheckedChanged(object sender, EventArgs e)
        {

            float AddOnPrice = 20;

            float TotalTextBox = float.Parse(LblTotal.Text);

            float Total = Total = AddOnPrice + TotalTextBox;

            LblTotal.Text = Total.ToString();
        }
    }
}