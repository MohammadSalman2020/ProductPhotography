﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UrunPhotography
{
    public partial class ProductCategoryandChecks : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //btnUpdate.Visible = false;
            btnUpdateAdd.Visible = false;
            lblmsg2.Visible = false;

            //lblmsg.Visible = false;
            MthdFillRepeaterCategory();
            MthdFillRepeaterAddsOn();
            if (!IsPostBack)
            {
                MthdFillDrpCategory();
            }
        }
        DBUrnPhotographyEntities db = new DBUrnPhotographyEntities();
        public void MthdFillRepeaterCategory()
        {
            //RptCategory.DataSource = db.tblAddOnCategories.ToList().OrderByDescending(p => p.AddOnCategoryID);
            //RptCategory.DataBind();
        }
        public void MthdFillRepeaterAddsOn()
        {
            RptAddons.DataSource = db.SpFillrepAddOn1().ToList().OrderByDescending(p => p.AddOnID);
            RptAddons.DataBind();
        }
        public void MthdFillDrpCategory()
        {
            DrpCategory.DataSource = (from a in db.tblAddOnCategories
                                      select new { a.AddOnCategoryID, a.CategoryDesc }).ToList();
            DrpCategory.DataValueField = "AddOnCategoryID";
            DrpCategory.DataTextField = "CategoryDesc";
            DrpCategory.DataBind();
        }

        //protected void btnAdd_Click(object sender, EventArgs e)
        //{
        //    if (txtCategoryName.Text.Trim() != string.Empty)
        //    {
        //        tblAddOnCategory obj = new tblAddOnCategory();

        //        obj.CategoryDesc = txtCategoryName.Text;
        //        db.tblAddOnCategories.Add(obj);
        //        db.SaveChanges();
        //        lblmsg.Visible = true;
        //        lblmsg.Text = "Category Added Succesfully";
        //        lblmsg.ForeColor = System.Drawing.Color.Green;
        //        MthdFillDrpCategory();
        //        txtCategoryName.Text = "";
        //        MthdFillRepeaterCategory();
        //    }
        //    else
        //    {
        //        lblmsg.Visible = true;
        //        lblmsg.Text = "Fill all feilds";
        //        lblmsg.ForeColor = System.Drawing.Color.Red;
        //    }
        //}

        //protected void RptCategory_ItemCommand(object source, RepeaterCommandEventArgs e)
        //{
        //    switch (e.CommandName)
        //    {

        //        case ("Edit"):

        //            //==== Getting id of the selelected record(We have passed on link button's command argument property).
        //            int id = Convert.ToInt32(e.CommandArgument);
        //            HiddenField1.Value = id.ToString();
        //            tblAddOnCategory obj1 = db.tblAddOnCategories.FirstOrDefault(r => r.AddOnCategoryID == id);


        //            txtCategoryName.Text = obj1.CategoryDesc;

        //            btnAdd.Visible = false;
        //            btnUpdate.Visible = true;

        //            break;
        //    }
        //}

        //protected void btnUpdate_Click(object sender, EventArgs e)
        //{
        //    try
        //    {

        //        int id = int.Parse(HiddenField1.Value);
        //        var row = db.tblAddOnCategories.Where(a => a.AddOnCategoryID == id).FirstOrDefault();
        //        if (row != null)
        //        {


        //            if (txtCategoryName.Text.Trim() != string.Empty)
        //            {


        //                row.CategoryDesc = txtCategoryName.Text;


        //                db.SaveChanges();
        //                MthdFillRepeaterCategory();

        //                txtCategoryName.Text = "";
        //                lblmsg.Visible = true;
        //                lblmsg.Text = "Record Updated Successfully";
        //                lblmsg.ForeColor = System.Drawing.Color.Green;

        //                btnAdd.Visible = true;
        //                btnUpdate.Visible = false;
        //            }
        //            else
        //            {
        //                lblmsg.Visible = true;
        //                lblmsg.Text = "Fill All Fields";
        //                lblmsg.ForeColor = System.Drawing.Color.Red;
        //            }




        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        ex.Message.ToString();
        //    }
        //}

        protected void btnAddOn_Click(object sender, EventArgs e)
        {
            if (txtAddonName.Text.Trim() != string.Empty)
            {
                tblAddOn obj = new tblAddOn();

                obj.AddOnCategoryID = int.Parse(DrpCategory.SelectedValue.ToString());
                obj.AddOn = txtAddonName.Text;
                if (txtPriceAddon.Text == "")
                {
                    obj.AddOnPrice ="";
                }
                else
                {
                    obj.AddOnPrice = txtPriceAddon.Text;
                }


                db.tblAddOns.Add(obj);
                db.SaveChanges();



                lblmsg2.Visible = true;
                lblmsg2.Text = "Record Added Succesfully";
                lblmsg2.ForeColor = System.Drawing.Color.Green;

                txtPriceAddon.Text = "";
                txtAddonName.Text = "";

                MthdFillRepeaterAddsOn();


            }
            else
            {
                lblmsg2.Visible = true;
                lblmsg2.Text = "Fill All Fields";
                lblmsg2.ForeColor = System.Drawing.Color.Red;
            }
        }

        protected void RptAddons_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField2.Value = id.ToString();
                    tblAddOn obj1 = db.tblAddOns.FirstOrDefault(r => r.AddOnID == id);


                    txtAddonName.Text = obj1.AddOn;
                    DrpCategory.SelectedValue = obj1.AddOnCategoryID.ToString();
                    txtPriceAddon.Text = obj1.AddOnPrice.ToString();



                    btnAddOn.Visible = false;
                    btnUpdateAdd.Visible = true;





                    break;
            }
        }

        protected void btnUpdateAdd_Click(object sender, EventArgs e)
        {
            try
            {

                int id = int.Parse(HiddenField2.Value);
                var row = db.tblAddOns.Where(a => a.AddOnID == id).FirstOrDefault();
                if (row != null)
                {


                    if (txtAddonName.Text.Trim() != string.Empty || txtPriceAddon.Text.Trim() != string.Empty)
                    {
                        row.AddOnCategoryID = int.Parse(DrpCategory.SelectedValue.ToString());


                        row.AddOnPrice = txtPriceAddon.Text;

                        row.AddOn = txtAddonName.Text;


                        db.SaveChanges();
                        MthdFillRepeaterAddsOn();

                        txtAddonName.Text = "";
                        txtPriceAddon.Text = "";
                        lblmsg2.Visible = true;
                        lblmsg2.Text = "Record Updated Successfully";
                        lblmsg2.ForeColor = System.Drawing.Color.Green;

                        btnAddOn.Visible = true;
                        btnUpdateAdd.Visible = false;
                    }
                    else
                    {
                        lblmsg2.Visible = true;
                        lblmsg2.Text = "Fill All Fields";
                        lblmsg2.ForeColor = System.Drawing.Color.Green;
                    }









                }


            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
    }
}