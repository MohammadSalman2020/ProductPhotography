﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UrunPhotography
{
    public partial class FrmAPUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                MthdFillDrpRole();
            }
            btnupdate.Visible = false;
            lblmsg.Visible = false;
            MthdFillRepeater();
        }
        public void MthdFillDrpRole()
        {
            DrpRole.DataSource = (from a in db.tblRoles
                                  select new { a.RoleID, a.RoleDesc }).ToList();
            DrpRole.DataValueField = "RoleID";
            DrpRole.DataTextField = "RoleDesc";
            DrpRole.DataBind();
        }
        public bool Empty()
        {
            if (txtEmail.Text.Trim() == string.Empty || txtFirstName.Text.Trim() == string.Empty
                || txtLastName.Text.Trim() == string.Empty || txtPwd.Text.Trim() == string.Empty)
            {

                return true;

            }
            else
            {
                return false;
            }
        }
        public void Clear()
        {
            txtPwd.Text = "";
            txtLastName.Text = "";
            txtFirstName.Text = "";
            txtEmail.Text = "";
        }
        DBUrnPhotographyEntities db = new DBUrnPhotographyEntities();
        public void MthdFillRepeater()
        {
            Repeater1.DataSource = db.SpFillRepUser().ToList().OrderByDescending(p => p.LoginID);
            Repeater1.DataBind();
        }

        protected void btnshopAdd_Click(object sender, EventArgs e)
        {
            if (!Empty())
            {
                tbllogin obj = new tbllogin();

                obj.FirstName = txtFirstName.Text;
                obj.LastName = txtLastName.Text;
                obj.PWD = txtPwd.Text;
                obj.Email = txtEmail.Text;
                obj.RoleID = int.Parse(DrpRole.SelectedValue.ToString());


                db.tbllogins.Add(obj);
                db.SaveChanges();


                lblmsg.Visible = true;
                lblmsg.Text = "Record updated successfully!";
                lblmsg.ForeColor = System.Drawing.Color.Green;


                MthdFillRepeater();
                Clear();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tbllogin obj1 = db.tbllogins.FirstOrDefault(r => r.LoginID == id);


                    txtPwd.Text = obj1.PWD;
                    txtLastName.Text = obj1.LastName;
                    txtFirstName.Text = obj1.FirstName;
                    txtEmail.Text = obj1.Email;
                    DrpRole.SelectedValue = obj1.RoleID.ToString();





                    btnshopAdd.Visible = false;
                    btnupdate.Visible = true;





                    break;
            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {

                int id = int.Parse(HiddenField1.Value);
                var row = db.tbllogins.Where(a => a.LoginID == id).FirstOrDefault();
                if (row != null)
                {





                    row.FirstName = txtFirstName.Text;
                    row.RoleID = int.Parse(DrpRole.SelectedValue.ToString());

                    row.LastName = txtLastName.Text;
                    row.PWD = txtPwd.Text;
                    row.Email = txtEmail.Text;

                    db.SaveChanges();





                    MthdFillRepeater();

                    Clear();
                    lblmsg.Visible = true;
                    lblmsg.Text = "Record Updated Successfully";
                    lblmsg.ForeColor = System.Drawing.Color.Green;

                    btnshopAdd.Visible = true;
                    btnupdate.Visible = false;
                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
    }
}