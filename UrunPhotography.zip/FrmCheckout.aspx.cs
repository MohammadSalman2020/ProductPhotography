﻿using Iyzipay;
using Iyzipay.Model;
using Iyzipay.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UrunPhotography
{
    public partial class FrmCheckout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            mthdFillRepeater();

            string IP = Session["IP"].ToString();
            var rec2 = db.tblAddtoCarts.Where(p => p.IP == IP).Sum(o => o.TotalAmount);

            float Subtotal = float.Parse(rec2.ToString()) * float.Parse(0.18.ToString());

            float TotalBill = float.Parse(rec2.ToString()) + Subtotal;

            //var s = string.Format("{0:0.00}", TotalBill);

            float rectotal = float.Parse(rec2.ToString());

            lblSubTotal.Text = rectotal.ToString("0.00");


            lblSalesTax.Text = TotalBill.ToString("0.00");



        }
        DBUrnPhotographyEntities db = new DBUrnPhotographyEntities();

        public void mthdFillRepeater()
        {
            string IP = Session["IP"].ToString();


            Repeater1.DataSource = db.SpFillRepAddToCardIPUpdated(IP).ToList().OrderByDescending(p => p.CardID);
            Repeater1.DataBind();


        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {

            string IP = Session["IP"].ToString();

            if (!Empty())
            {
                tblCustomer obj = new tblCustomer();
                obj.Addresss = txtAddress.Text;
                obj.C_State = txtState.Text;
                obj.City = DrpCity.SelectedItem.Text;
                obj.Country = txtCountry.Text;
                obj.Email = txtEmail.Text;
                obj.FirstName = txtFirstName.Text;
                obj.LastName = txtLastname.Text;
                obj.IP = IP;
                obj.LastName = txtLastname.Text;
                obj.PhoneNumber = txtPhone.Text;
                obj.PWD = "123";
                obj.ZipCode = txtZipCode.Text;

                db.tblCustomers.Add(obj);
                db.SaveChanges();


                int CustID = db.tblCustomers.Max(u => u.CutomerID);

                tbllogin obj2 = new tbllogin();

                obj2.RoleID = 2;
                obj2.FirstName = txtFirstName.Text;
                obj2.LastName = txtLastname.Text;
                obj2.PWD = "123";
                obj2.Email = txtEmail.Text;

                obj2.CustomerID = CustID;

                db.tbllogins.Add(obj2);
                db.SaveChanges();



                db.SpInsertConfirmOrder(IP);
                db.SaveChanges();

                int OrderID = db.tblOrders.Max(u => u.OrderID);




                var rec2 = db.tblOrders.Where(o => o.OrderID == OrderID).Sum(o => o.TotalAmount);

                float Subtotal = float.Parse(rec2.ToString()) * float.Parse(0.18.ToString());

                float TotalBill = float.Parse(rec2.ToString()) + Subtotal;

                lblSalesTax.Text = TotalBill.ToString("0.00");

                tblOrderDetail obj3 = new tblOrderDetail();

                obj3.CustomerID = CustID;
                obj3.OrderID = OrderID;
                obj3.OrderStatus = "Un-Paid";
                obj3.SalesTax = 18.00;
                obj3.TotalAfterSaleTax = TotalBill;

                db.tblOrderDetails.Add(obj3);
                db.SaveChanges();




                mthdFillRepeater();

                //     var row = db.tblProducts.Where(a => a.ProductID == id).FirstOrDefault();

                try
                {
                    Options options = new Options();
                    options.ApiKey = "sandbox-g40GQsDFh2yBVLEXL8ST7mA7KLDCU5PQ";
                    options.SecretKey = "sandbox-zpLbG4TID9eqG2aHRhWp72KBRcsiO49C";
                    options.BaseUrl = "https://sandbox-api.iyzipay.com";

                    CreatePaymentRequest request = new CreatePaymentRequest();
                    request.Locale = Locale.TR.ToString();
                    //    request.ConversationId = "123456789";
                    request.Price = lblSalesTax.Text;
                    request.PaidPrice = lblSalesTax.Text;
                    request.Currency = Currency.TRY.ToString();
                    request.Installment = 1;
                    //  request.BasketId = "B67832";
                    request.PaymentChannel = PaymentChannel.WEB.ToString();
                    request.PaymentGroup = PaymentGroup.PRODUCT.ToString();

                    PaymentCard paymentCard = new PaymentCard();
                    paymentCard.CardHolderName = txtCardHolderName.Text;
                    paymentCard.CardNumber = txtCardNumber.Text;
                    paymentCard.ExpireMonth = (DRPMONTH.SelectedIndex+1).ToString();
                    paymentCard.ExpireYear = txtyear.Text;
                    paymentCard.Cvc = txtCVC.Text;
                    paymentCard.RegisterCard = 0;
                    request.PaymentCard = paymentCard;

                    Buyer buyer = new Buyer();
                    buyer.Id = CustID.ToString();
                    buyer.Name = txtFirstName.Text;
                    buyer.Surname = txtLastname.Text;
                    //  buyer.GsmNumber = "+905350000000";
                    buyer.Email = txtEmail.Text;
                    buyer.IdentityNumber ="0000"+ CustID.ToString();
                    //     buyer.LastLoginDate = "2015-10-05 12:43:35";
                    //   buyer.RegistrationDate = "2013-04-21 15:12:09";
                    buyer.RegistrationAddress = txtAddress.Text;
                    // buyer.Ip = "85.34.78.112";
                    buyer.City = DrpCity.SelectedItem.Text;
                    buyer.Country =txtCountry.Text;
                    buyer.ZipCode = txtZipCode.Text;
                    request.Buyer = buyer;

                    Address shippingAddress = new Address();
                    shippingAddress.ContactName = txtCardHolderName.Text;
                    shippingAddress.City = DrpCity.SelectedItem.Text;
                    shippingAddress.Country = txtCountry.Text;
                    shippingAddress.Description = txtdesc.Text;
                    shippingAddress.ZipCode = txtZipCode.Text;
                    request.ShippingAddress = shippingAddress;

                    Address billingAddress = new Address();
                    billingAddress.ContactName = txtCardHolderName.Text;
                    billingAddress.City =  DrpCity.SelectedItem.Text;
                    billingAddress.Country = txtCountry.Text;
                    billingAddress.Description = txtdesc.Text;
                    billingAddress.ZipCode = txtZipCode.Text;
                    request.BillingAddress = billingAddress;


                    tblOrder obj5 = db.tblOrders.FirstOrDefault(p => p.OrderID == OrderID);


                    List<BasketItem> basketItems = new List<BasketItem>();
                    BasketItem firstBasketItem = new BasketItem();
                    firstBasketItem.Id = OrderID.ToString();
                    firstBasketItem.Name =obj5.OrderID.ToString();
                   
                    firstBasketItem.Category1 = obj5.ProductType;
                    firstBasketItem.Category2 = "Photography";
                    firstBasketItem.ItemType = BasketItemType.PHYSICAL.ToString();
                    firstBasketItem.Price = lblSalesTax.Text;
                    basketItems.Add(firstBasketItem);
                    request.BasketItems = basketItems;


                    Payment payment = Payment.Create(request, options);

                    //Console.WriteLine("Success");
                }
                catch (Exception ex)
                {
                    //Console.WriteLine("Error");
                }

                Response.Redirect("FrmThankYou.aspx");


            }
        }

        public bool Empty()
        {
            if (txtAddress.Text.Trim() == string.Empty ||  txtCountry.Text.Trim() == string.Empty || txtEmail.Text.Trim() == string.Empty
                || txtFirstName.Text.Trim() == string.Empty
                || txtLastname.Text.Trim() == string.Empty
                || txtPhone.Text.Trim() == string.Empty
                || txtPwd.Text.Trim() == string.Empty
                || txtState.Text.Trim() == string.Empty
                || txtZipCode.Text.Trim() == string.Empty || txtEmail.Text.Trim() == string.Empty)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();

                    db.SpDeleteCartProduct(id);
                    db.SaveChanges();

                    mthdFillRepeater();


                    break;
            }
        }
    }
}