﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UrunPhotography
{
    public partial class frmCart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            mthdFillRepeater();
        }
        DBUrnPhotographyEntities db = new DBUrnPhotographyEntities();
        public void mthdFillRepeater()
        {
            string IP = Session["IP"].ToString();

            //if (Session["Type"] == "Product")
            //{
            //Repeater2.Visible = false;
            Repeater1.DataSource = db.SpFillRepAddToCardIPUpdated(IP).ToList().OrderByDescending(p => p.CardID);
            Repeater1.DataBind();
            //}

            //else if (Session["Type"] == "Clothing")
            //{
            //    Repeater1.Visible = false;
            //    Repeater2.DataSource = db.SpFillRepAddToCardIPClothing(IP).ToList().OrderByDescending(p => p.CardID);
            //    Repeater2.DataBind();
            //}



        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();

                    db.SpDeleteCartProduct(id);
                    db.SaveChanges();

                    mthdFillRepeater();


                    break;
            }
        }

        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmCheckout.aspx");
        }
    }
}