﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Urunfotografim.RoleManagement
{
    public class WebsiteRoles
    {
        public static string Admin = "1";
        public static string Customer = "2";
        public static bool IsAdministrater()
        {
            if (System.Web.HttpContext.Current.Session["RoleID"].ToString() == WebsiteRoles.Admin)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool IsCustomer()
        {
            if (System.Web.HttpContext.Current.Session["RoleID"].ToString() == WebsiteRoles.Customer)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}