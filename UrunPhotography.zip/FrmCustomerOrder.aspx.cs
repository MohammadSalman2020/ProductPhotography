﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UrunPhotography
{
    public partial class FrmCustomerOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            mthdFillRepeater();
        }

        DBUrnPhotographyEntities db = new DBUrnPhotographyEntities();
        public void mthdFillRepeater()
        {
            int Customer = int.Parse(Session["CustomerID"].ToString());


            Repeater1.DataSource = db.SpFillRepOrderCustomer(Customer).ToList().OrderByDescending(p => p.OrderID);
            Repeater1.DataBind();


        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();


                    tblOrderDetail obj1 = db.tblOrderDetails.FirstOrDefault(r => r.OrderID == id);

                    string link = obj1.OrderLink;

                    Response.Redirect(link);



                    break;
            }
        }
    }
}